//
//  IgnitebleButton.h
//  Igniteble
//
//  Created by Peter Dupris on 1/15/15.
//  Copyright (c) 2015 Ignite BLE, LLC. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface IgnitebleButton : UIControl

@end
